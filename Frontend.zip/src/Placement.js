import React from 'react';
import img from  './placement.jpg';
const Placement = () => {
    return (
        <div className='placement'>
            <center>Think Placement...Think Institute</center>
            <center>
            <div style={{marginTop:'150px'}}>
            
            <img src={img} height={500}/>
            </div>
            
            </center>
        </div>
    );
}

export default Placement;
